#!/bin/sh
# Render / similar platforms startup script
pip install -r requirements.txt
exec python3 -u lenskart_bot.py
